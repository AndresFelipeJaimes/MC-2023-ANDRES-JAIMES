X = [0,1,2,3,4,5,6,7]
Y = [3.5, 2.5, 3, 1.5, 2, 1.3, 1, 0.3]
Multiplicacion = 0
SumaX = 0
SumaY = 0
SumaX2 = 0
SumaX3 = 0
n = len(X)
for i in range(n):
  Multiplicacion = X[i]*Y[i] + Multiplicacion
  SumaX = X[i] + SumaX
  SumaY = Y[i] + SumaY
  SumaX2 = (X[i] ** 2) + SumaX2
Resultado = (n * Multiplicacion - SumaY*SumaX)/ (n*SumaX2 - (SumaX**2))
Resultado2 = (SumaY/n) - Resultado*(SumaX/n)
print("El resultado de a1 es: ", Resultado)
print("El resultado de a0 es: ", Resultado2)