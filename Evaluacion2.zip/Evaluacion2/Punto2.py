import numpy as np
import matplotlib.pyplot as plt

# Puntos de entrada
x = np.array([1, 2, 3, 4, 5, 6, 7, 8])
y = np.array([1.8, 2, 2.2, 2.6, 2.9, 3.3, 3.7, 4.1])

# Aproximación lineal
coefficients_linear = np.polyfit(x, y, 1)
poly_linear = np.poly1d(coefficients_linear)
x_linear = np.linspace(min(x), max(x), 100)
y_linear = poly_linear(x_linear)

# Aproximación polinomial de grado 2
coefficients_poly2 = np.polyfit(x, y, 2)
poly_poly2 = np.poly1d(coefficients_poly2)
x_poly2 = np.linspace(min(x), max(x), 100)
y_poly2 = poly_poly2(x_poly2)

# Gráfica de los puntos y las funciones aproximadas
plt.scatter(x, y, color='red', label='Datos')
plt.plot(x_linear, y_linear, label='Aproximación lineal')
plt.plot(x_poly2, y_poly2, label='Aproximación polinomial de grado 2')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
plt.title('Aproximación lineal y polinomial de grado 2')
plt.show()