import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline

xi = np.array([1, 2, 3, 4, 5])
fi = np.array([1.8, 2, 2.5, 2.8, 3.5])

# Calcular los coeficientes de los trazadores cúbicos
spl = CubicSpline(xi, fi)

# Estimar el valor de f(3.2)
x_estimation = 3.2
f_estimation = spl(x_estimation)
print("Estimación de f(3.2):", f_estimation)

# Crear puntos para la gráfica
x_plot = np.linspace(xi.min(), xi.max(), 100)
y_plot = spl(x_plot)

# Graficar los puntos y los trazadores cúbicos
plt.scatter(xi, fi, color='red', label='Puntos')
plt.plot(x_plot, y_plot, label='Trazadores cúbicos')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title('Trazadores cúbicos')
plt.legend()
plt.show()