import math
X = [2,4,6,8,10,12]
Y = [0.78845736 ,1.098612289 ,1.504077397 ,1.791759469 ,2.140066163 ,2.48490665]
Multiplicacion = 0
SumaX = 0
SumaY = 0
SumaX2 = 0
SumaX3 = 0
n = len(X)
for i in range(n):
  Multiplicacion = X[i]*Y[i] + Multiplicacion
  SumaX = X[i] + SumaX
  SumaY = Y[i] + SumaY
  SumaX2 = (X[i] ** 2) + SumaX2
Resultado = (n * Multiplicacion - SumaY*SumaX)/ (n*SumaX2 - (SumaX**2))
Resultado2 = (SumaY/n) - Resultado*(SumaX/n)
print("El resultado de a1 es: ", Resultado)
print("El resultado de a0 es: ", Resultado2)
Alfa= math.e ** Resultado2
print("El resultado de alfa es: ", Alfa)
print("El resultado de beta es: ", Resultado)
print("El resultado de la funcion es: ", Alfa, "e^", Resultado, "x")