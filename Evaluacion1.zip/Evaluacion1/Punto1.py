Conjunto1 = {1, 4, 6, 9, 12, 20, 30}
Conjunto2 = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24}
Conjunto3 = {6,10,14,18,22,26,30,34}
print("Los conjuntos iniciales son:\nConjunto 1.\n", Conjunto1, "\nConjunto .\n", Conjunto2, "\nConjunto 3.\n", Conjunto3)
#Operacion1
Operacion1 = (Conjunto2^Conjunto3)&(Conjunto1|Conjunto3)
print("El resultado de la operacion 1 es:\n", Operacion1)
#Operacion2
Operacion2 = ((Conjunto1-Conjunto2)&Conjunto3)^(Conjunto2|Conjunto3)
print("El resultado de la operacion 2 es:\n", Operacion2)
#Operacion3
Operacion3 = ((Conjunto1-Conjunto3)|(Conjunto2&Conjunto1))-(Conjunto1|Conjunto2|Conjunto3)
print("El resultado de la operacion 3 es:\n", Operacion3)